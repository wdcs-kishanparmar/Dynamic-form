/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/[formURL]/page";
exports.ids = ["app/[formURL]/page"];
exports.modules = {

/***/ "./action-async-storage.external":
/*!****************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external" ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/action-async-storage.external");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "./request-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "./static-generation-async-storage.external":
/*!***************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external" ***!
  \***************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2F%5BformURL%5D%2Fpage&page=%2F%5BformURL%5D%2Fpage&appPaths=%2F%5BformURL%5D%2Fpage&pagePath=private-next-app-dir%2F%5BformURL%5D%2Fpage.tsx&appDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2F%5BformURL%5D%2Fpage&page=%2F%5BformURL%5D%2Fpage&appPaths=%2F%5BformURL%5D%2Fpage&pagePath=private-next-app-dir%2F%5BformURL%5D%2Fpage.tsx&appDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   __next_app__: () => (/* binding */ __next_app__),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   pages: () => (/* binding */ pages),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   tree: () => (/* binding */ tree)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-page/module.compiled */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/module.compiled.js?9d97\");\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/client/components/error-boundary */ \"(rsc)/./node_modules/next/dist/client/components/error-boundary.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dist/server/app-render/entry-base */ \"(rsc)/./node_modules/next/dist/server/app-render/entry-base.js\");\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if([\"default\",\"tree\",\"pages\",\"GlobalError\",\"originalPathname\",\"__next_app__\",\"routeModule\"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\"TURBOPACK { transition: next-ssr }\";\n\n\n// We inject the tree and pages here so that we can use them in the route\n// module.\nconst tree = {\n        children: [\n        '',\n        {\n        children: [\n        '[formURL]',\n        {\n        children: ['__PAGE__', {}, {\n          page: [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/[formURL]/page.tsx */ \"(rsc)/./app/[formURL]/page.tsx\")), \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\"],\n          \n        }]\n      },\n        {\n        \n        \n      }\n      ]\n      },\n        {\n        'layout': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/layout.tsx */ \"(rsc)/./app/layout.tsx\")), \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/layout.tsx\"],\n'not-found': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! next/dist/client/components/not-found-error */ \"(rsc)/./node_modules/next/dist/client/components/not-found-error.js\", 23)), \"next/dist/client/components/not-found-error\"],\n        \n      }\n      ]\n      }.children;\nconst pages = [\"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\"];\n\n\nconst __next_app_require__ = __webpack_require__\nconst __next_app_load_chunk__ = () => Promise.resolve()\nconst originalPathname = \"/[formURL]/page\";\nconst __next_app__ = {\n    require: __next_app_require__,\n    loadChunk: __next_app_load_chunk__\n};\n\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,\n        page: \"/[formURL]/page\",\n        pathname: \"/[formURL]\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\",\n        appPaths: []\n    },\n    userland: {\n        loaderTree: tree\n    }\n});\n\n//# sourceMappingURL=app-page.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkYlNUJmb3JtVVJMJTVEJTJGcGFnZSZwYWdlPSUyRiU1QmZvcm1VUkwlNUQlMkZwYWdlJmFwcFBhdGhzPSUyRiU1QmZvcm1VUkwlNUQlMkZwYWdlJnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGJTVCZm9ybVVSTCU1RCUyRnBhZ2UudHN4JmFwcERpcj0lMkZob21lJTJGd2ViY2x1ZXMlMkZEZXNrdG9wJTJGTGl2ZS1Qcm9qZWN0cyUyRkR5bmFtaWMtZm9ybSUyRmR5bmFtaWMtZm9ybSUyRmFwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0maXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxhQUFhLHNCQUFzQjtBQUNpRTtBQUNyQztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakMsdUJBQXVCLDRKQUEwSDtBQUNqSjtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLHlCQUF5Qiw0SUFBa0g7QUFDM0ksb0JBQW9CLDBOQUFnRjtBQUNwRztBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDdUI7QUFDNkQ7QUFDcEYsNkJBQTZCLG1CQUFtQjtBQUNoRDtBQUNPO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDdUQ7QUFDdkQ7QUFDTyx3QkFBd0IsOEdBQWtCO0FBQ2pEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsid2VicGFjazovL2R5bmFtaWMtZm9ybS8/MDk0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJcIlRVUkJPUEFDSyB7IHRyYW5zaXRpb246IG5leHQtc3NyIH1cIjtcbmltcG9ydCB7IEFwcFBhZ2VSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL2FwcC1wYWdlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbi8vIFdlIGluamVjdCB0aGUgdHJlZSBhbmQgcGFnZXMgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IHRyZWUgPSB7XG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICcnLFxuICAgICAgICB7XG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICdbZm9ybVVSTF0nLFxuICAgICAgICB7XG4gICAgICAgIGNoaWxkcmVuOiBbJ19fUEFHRV9fJywge30sIHtcbiAgICAgICAgICBwYWdlOiBbKCkgPT4gaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvaG9tZS93ZWJjbHVlcy9EZXNrdG9wL0xpdmUtUHJvamVjdHMvRHluYW1pYy1mb3JtL2R5bmFtaWMtZm9ybS9hcHAvW2Zvcm1VUkxdL3BhZ2UudHN4XCIpLCBcIi9ob21lL3dlYmNsdWVzL0Rlc2t0b3AvTGl2ZS1Qcm9qZWN0cy9EeW5hbWljLWZvcm0vZHluYW1pYy1mb3JtL2FwcC9bZm9ybVVSTF0vcGFnZS50c3hcIl0sXG4gICAgICAgICAgXG4gICAgICAgIH1dXG4gICAgICB9LFxuICAgICAgICB7XG4gICAgICAgIFxuICAgICAgICBcbiAgICAgIH1cbiAgICAgIF1cbiAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgJ2xheW91dCc6IFsoKSA9PiBpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL3dlYmNsdWVzL0Rlc2t0b3AvTGl2ZS1Qcm9qZWN0cy9EeW5hbWljLWZvcm0vZHluYW1pYy1mb3JtL2FwcC9sYXlvdXQudHN4XCIpLCBcIi9ob21lL3dlYmNsdWVzL0Rlc2t0b3AvTGl2ZS1Qcm9qZWN0cy9EeW5hbWljLWZvcm0vZHluYW1pYy1mb3JtL2FwcC9sYXlvdXQudHN4XCJdLFxuJ25vdC1mb3VuZCc6IFsoKSA9PiBpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIm5leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9ub3QtZm91bmQtZXJyb3JcIiksIFwibmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL25vdC1mb3VuZC1lcnJvclwiXSxcbiAgICAgICAgXG4gICAgICB9XG4gICAgICBdXG4gICAgICB9LmNoaWxkcmVuO1xuY29uc3QgcGFnZXMgPSBbXCIvaG9tZS93ZWJjbHVlcy9EZXNrdG9wL0xpdmUtUHJvamVjdHMvRHluYW1pYy1mb3JtL2R5bmFtaWMtZm9ybS9hcHAvW2Zvcm1VUkxdL3BhZ2UudHN4XCJdO1xuZXhwb3J0IHsgdHJlZSwgcGFnZXMgfTtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgR2xvYmFsRXJyb3IgfSBmcm9tIFwibmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL2Vycm9yLWJvdW5kYXJ5XCI7XG5jb25zdCBfX25leHRfYXBwX3JlcXVpcmVfXyA9IF9fd2VicGFja19yZXF1aXJlX19cbmNvbnN0IF9fbmV4dF9hcHBfbG9hZF9jaHVua19fID0gKCkgPT4gUHJvbWlzZS5yZXNvbHZlKClcbmV4cG9ydCBjb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvW2Zvcm1VUkxdL3BhZ2VcIjtcbmV4cG9ydCBjb25zdCBfX25leHRfYXBwX18gPSB7XG4gICAgcmVxdWlyZTogX19uZXh0X2FwcF9yZXF1aXJlX18sXG4gICAgbG9hZENodW5rOiBfX25leHRfYXBwX2xvYWRfY2h1bmtfX1xufTtcbmV4cG9ydCAqIGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2FwcC1yZW5kZXIvZW50cnktYmFzZVwiO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUGFnZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUEFHRSxcbiAgICAgICAgcGFnZTogXCIvW2Zvcm1VUkxdL3BhZ2VcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL1tmb3JtVVJMXVwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiLFxuICAgICAgICBhcHBQYXRoczogW11cbiAgICB9LFxuICAgIHVzZXJsYW5kOiB7XG4gICAgICAgIGxvYWRlclRyZWU6IHRyZWVcbiAgICB9XG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXBwLXBhZ2UuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2F%5BformURL%5D%2Fpage&page=%2F%5BformURL%5D%2Fpage&appPaths=%2F%5BformURL%5D%2Fpage&pagePath=private-next-app-dir%2F%5BformURL%5D%2Fpage.tsx&appDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp%2F%5BformURL%5D%2Fpage.tsx&server=true!":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp%2F%5BformURL%5D%2Fpage.tsx&server=true! ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/[formURL]/page.tsx */ \"(ssr)/./app/[formURL]/page.tsx\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0lMkZhcHAlMkYlNUJmb3JtVVJMJTVEJTJGcGFnZS50c3gmc2VydmVyPXRydWUhIiwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZHluYW1pYy1mb3JtLz8zM2YzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvd2ViY2x1ZXMvRGVza3RvcC9MaXZlLVByb2plY3RzL0R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0vYXBwL1tmb3JtVVJMXS9wYWdlLnRzeFwiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp%2F%5BformURL%5D%2Fpage.tsx&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true! ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/app-router.js */ \"(ssr)/./node_modules/next/dist/client/components/app-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/error-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/error-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/layout-router.js */ \"(ssr)/./node_modules/next/dist/client/components/layout-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/not-found-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/not-found-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/render-from-template-context.js */ \"(ssr)/./node_modules/next/dist/client/components/render-from-template-context.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js */ \"(ssr)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0lMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZhcHAtcm91dGVyLmpzJm1vZHVsZXM9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0lMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZlcnJvci1ib3VuZGFyeS5qcyZtb2R1bGVzPSUyRmhvbWUlMkZ3ZWJjbHVlcyUyRkRlc2t0b3AlMkZMaXZlLVByb2plY3RzJTJGRHluYW1pYy1mb3JtJTJGZHluYW1pYy1mb3JtJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGbGF5b3V0LXJvdXRlci5qcyZtb2R1bGVzPSUyRmhvbWUlMkZ3ZWJjbHVlcyUyRkRlc2t0b3AlMkZMaXZlLVByb2plY3RzJTJGRHluYW1pYy1mb3JtJTJGZHluYW1pYy1mb3JtJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGbm90LWZvdW5kLWJvdW5kYXJ5LmpzJm1vZHVsZXM9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0lMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZyZW5kZXItZnJvbS10ZW1wbGF0ZS1jb250ZXh0LmpzJm1vZHVsZXM9JTJGaG9tZSUyRndlYmNsdWVzJTJGRGVza3RvcCUyRkxpdmUtUHJvamVjdHMlMkZEeW5hbWljLWZvcm0lMkZkeW5hbWljLWZvcm0lMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZzdGF0aWMtZ2VuZXJhdGlvbi1zZWFyY2hwYXJhbXMtYmFpbG91dC1wcm92aWRlci5qcyZzZXJ2ZXI9dHJ1ZSEiLCJtYXBwaW5ncyI6IkFBQUEsa09BQTBKO0FBQzFKLDBPQUE4SjtBQUM5Six3T0FBNko7QUFDN0osa1BBQWtLO0FBQ2xLLHNRQUE0SztBQUM1SyIsInNvdXJjZXMiOlsid2VicGFjazovL2R5bmFtaWMtZm9ybS8/MDhhNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL3dlYmNsdWVzL0Rlc2t0b3AvTGl2ZS1Qcm9qZWN0cy9EeW5hbWljLWZvcm0vZHluYW1pYy1mb3JtL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvYXBwLXJvdXRlci5qc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvd2ViY2x1ZXMvRGVza3RvcC9MaXZlLVByb2plY3RzL0R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9lcnJvci1ib3VuZGFyeS5qc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvd2ViY2x1ZXMvRGVza3RvcC9MaXZlLVByb2plY3RzL0R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9sYXlvdXQtcm91dGVyLmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvaG9tZS93ZWJjbHVlcy9EZXNrdG9wL0xpdmUtUHJvamVjdHMvRHluYW1pYy1mb3JtL2R5bmFtaWMtZm9ybS9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL25vdC1mb3VuZC1ib3VuZGFyeS5qc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL2hvbWUvd2ViY2x1ZXMvRGVza3RvcC9MaXZlLVByb2plY3RzL0R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9yZW5kZXItZnJvbS10ZW1wbGF0ZS1jb250ZXh0LmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvaG9tZS93ZWJjbHVlcy9EZXNrdG9wL0xpdmUtUHJvamVjdHMvRHluYW1pYy1mb3JtL2R5bmFtaWMtZm9ybS9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL3N0YXRpYy1nZW5lcmF0aW9uLXNlYXJjaHBhcmFtcy1iYWlsb3V0LXByb3ZpZGVyLmpzXCIpIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%22path%22%3A%22app%2Flayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp%2Fglobals.css&server=true!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%22path%22%3A%22app%2Flayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&modules=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp%2Fglobals.css&server=true! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./app/[formURL]/page.tsx":
/*!********************************!*\
  !*** ./app/[formURL]/page.tsx ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ \"(ssr)/../../../../node_modules/axios/lib/axios.js\");\n/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constant */ \"(ssr)/./app/constant.ts\");\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\n\n\nconst FormPage = (props)=>{\n    const [formData, setFormData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const fetchData = async ()=>{\n            try {\n                const response = await axios__WEBPACK_IMPORTED_MODULE_3__[\"default\"].get(`${_constant__WEBPACK_IMPORTED_MODULE_2__.API_ROUTE.GET_FORM_BY_URL}/${props.params.formURL}`);\n                if (response && response.data) {\n                    setFormData(response?.data);\n                }\n            } catch (error) {\n                console.error(_constant__WEBPACK_IMPORTED_MODULE_2__.ERROR_MESSAGE.GET_FORM_BY_URL, error);\n            }\n        };\n        if (props.params.formURL) {\n            fetchData();\n        }\n    }, [\n        props.params.formURL\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"min-h-screen bg-gray-100 p-0 sm:p-12\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"mx-auto max-w-[45rem] px-6 py-12 bg-white border-0 shadow-lg sm:rounded-3xl\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                        className: \"text-2xl font-bold mb-4\",\n                        children: formData?.formName\n                    }, void 0, false, {\n                        fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                        lineNumber: 33,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"pb-12\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"hr\", {}, void 0, false, {\n                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                            lineNumber: 35,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                        lineNumber: 34,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                        className: \"max-w-2xl mx-auto\",\n                        children: [\n                            formData?.questions && formData.questions.map((field, index)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                    className: \"mb-6\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                                            className: \"  text-black font-semibold \",\n                                            children: field.title\n                                        }, void 0, false, {\n                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                            lineNumber: 42,\n                                            columnNumber: 19\n                                        }, undefined),\n                                        field.answerType === \"Text\" && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                            type: \"text\",\n                                            placeholder: \"Your answer\",\n                                            name: field.title.toLowerCase().replace(\" \", \"_\"),\n                                            className: \"pt-3 pb-2 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-300\"\n                                        }, void 0, false, {\n                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                            lineNumber: 46,\n                                            columnNumber: 21\n                                        }, undefined),\n                                        field.answerType === \"Multichoice Checkbox\" && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                            children: field.choices.map((choice, choiceIndex)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                                    className: \"pt-3\",\n                                                    children: [\n                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                                            type: \"checkbox\",\n                                                            name: field.title.toLowerCase().replace(\" \", \"_\"),\n                                                            value: choice,\n                                                            className: \"mr-5 text-black border-2 border-gray-300 focus:border-gray-300 focus:ring-black\"\n                                                        }, void 0, false, {\n                                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                            lineNumber: 57,\n                                                            columnNumber: 27\n                                                        }, undefined),\n                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                                                            children: choice\n                                                        }, void 0, false, {\n                                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                            lineNumber: 63,\n                                                            columnNumber: 27\n                                                        }, undefined)\n                                                    ]\n                                                }, choiceIndex, true, {\n                                                    fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                    lineNumber: 56,\n                                                    columnNumber: 25\n                                                }, undefined))\n                                        }, void 0, false, {\n                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                            lineNumber: 54,\n                                            columnNumber: 21\n                                        }, undefined),\n                                        field.answerType === \"Single Select radio\" && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                            children: field.choices.map((choice, choiceIndex)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                                        className: \"block pt-3  space-x-4\",\n                                                        children: [\n                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                                                type: \"radio\",\n                                                                name: field.title.toLowerCase().replace(\" \", \"_\"),\n                                                                value: choice,\n                                                                className: \"mr-2 text-black border-2 border-gray-300 focus:border-gray-300 focus:ring-black\"\n                                                            }, void 0, false, {\n                                                                fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                                lineNumber: 76,\n                                                                columnNumber: 29\n                                                            }, undefined),\n                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"label\", {\n                                                                children: choice\n                                                            }, void 0, false, {\n                                                                fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                                lineNumber: 82,\n                                                                columnNumber: 29\n                                                            }, undefined)\n                                                        ]\n                                                    }, choiceIndex, true, {\n                                                        fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                                        lineNumber: 72,\n                                                        columnNumber: 27\n                                                    }, undefined)\n                                                }, void 0, false))\n                                        }, void 0, false, {\n                                            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                            lineNumber: 69,\n                                            columnNumber: 21\n                                        }, undefined)\n                                    ]\n                                }, index, true, {\n                                    fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                    lineNumber: 41,\n                                    columnNumber: 17\n                                }, undefined)),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                type: \"submit\",\n                                className: \"px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600\",\n                                children: \"Submit\"\n                            }, void 0, false, {\n                                fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                                lineNumber: 90,\n                                columnNumber: 13\n                            }, undefined)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                        lineNumber: 38,\n                        columnNumber: 11\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n                lineNumber: 32,\n                columnNumber: 9\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx\",\n            lineNumber: 31,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormPage);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9hcHAvW2Zvcm1VUkxdL3BhZ2UudHN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQzRDO0FBQ2xCO0FBQzZCO0FBR3ZELE1BQU1LLFdBQVcsQ0FBQ0M7SUFDaEIsTUFBTSxDQUFDQyxVQUFVQyxZQUFZLEdBQUdQLCtDQUFRQSxDQUFrQjtJQUUxREQsZ0RBQVNBLENBQUM7UUFDUixNQUFNUyxZQUFZO1lBQ2hCLElBQUk7Z0JBQ0YsTUFBTUMsV0FBVyxNQUFNUiw2Q0FBS0EsQ0FBQ1MsR0FBRyxDQUM5QixDQUFDLEVBQUVSLGdEQUFTQSxDQUFDUyxlQUFlLENBQUMsQ0FBQyxFQUFFTixNQUFNTyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDO2dCQUV4RCxJQUFJSixZQUFZQSxTQUFTSyxJQUFJLEVBQUU7b0JBQzdCUCxZQUFZRSxVQUFVSztnQkFDeEI7WUFDRixFQUFFLE9BQU9DLE9BQU87Z0JBQ2RDLFFBQVFELEtBQUssQ0FBQ1osb0RBQWFBLENBQUNRLGVBQWUsRUFBRUk7WUFDL0M7UUFDRjtRQUVBLElBQUlWLE1BQU1PLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFO1lBQ3hCTDtRQUNGO0lBQ0YsR0FBRztRQUFDSCxNQUFNTyxNQUFNLENBQUNDLE9BQU87S0FBQztJQUV6QixxQkFDRTtrQkFDRSw0RUFBQ0k7WUFBSUMsV0FBVTtzQkFDYiw0RUFBQ0Q7Z0JBQUlDLFdBQVU7O2tDQUNiLDhEQUFDQzt3QkFBR0QsV0FBVTtrQ0FBMkJaLFVBQVVjOzs7Ozs7a0NBQ25ELDhEQUFDSDt3QkFBSUMsV0FBVTtrQ0FDYiw0RUFBQ0c7Ozs7Ozs7Ozs7a0NBR0gsOERBQUNDO3dCQUFLSixXQUFVOzs0QkFDYlosVUFBVWlCLGFBQ1RqQixTQUFTaUIsU0FBUyxDQUFDQyxHQUFHLENBQUMsQ0FBQ0MsT0FBa0JDLHNCQUN4Qyw4REFBQ1Q7b0NBQWdCQyxXQUFVOztzREFDekIsOERBQUNTOzRDQUFNVCxXQUFVO3NEQUNkTyxNQUFNRyxLQUFLOzs7Ozs7d0NBRWJILE1BQU1JLFVBQVUsS0FBSyx3QkFDcEIsOERBQUNDOzRDQUNDQyxNQUFLOzRDQUNMQyxhQUFZOzRDQUNaQyxNQUFNUixNQUFNRyxLQUFLLENBQUNNLFdBQVcsR0FBR0MsT0FBTyxDQUFDLEtBQUs7NENBQzdDakIsV0FBVTs7Ozs7O3dDQUdiTyxNQUFNSSxVQUFVLEtBQUssd0NBQ3BCLDhEQUFDWjtzREFDRVEsTUFBTVcsT0FBTyxDQUFDWixHQUFHLENBQUMsQ0FBQ2EsUUFBYUMsNEJBQy9CLDhEQUFDckI7b0RBQXNCQyxXQUFVOztzRUFDL0IsOERBQUNZOzREQUNDQyxNQUFLOzREQUNMRSxNQUFNUixNQUFNRyxLQUFLLENBQUNNLFdBQVcsR0FBR0MsT0FBTyxDQUFDLEtBQUs7NERBQzdDSSxPQUFPRjs0REFDUG5CLFdBQVU7Ozs7OztzRUFFWiw4REFBQ1M7c0VBQU9VOzs7Ozs7O21EQVBBQzs7Ozs7Ozs7Ozt3Q0FZZmIsTUFBTUksVUFBVSxLQUFLLHVDQUNwQiw4REFBQ1o7c0RBQ0VRLE1BQU1XLE9BQU8sQ0FBQ1osR0FBRyxDQUFDLENBQUNhLFFBQWFDLDRCQUMvQjs4REFDRSw0RUFBQ3JCO3dEQUVDQyxXQUFVOzswRUFFViw4REFBQ1k7Z0VBQ0NDLE1BQUs7Z0VBQ0xFLE1BQU1SLE1BQU1HLEtBQUssQ0FBQ00sV0FBVyxHQUFHQyxPQUFPLENBQUMsS0FBSztnRUFDN0NJLE9BQU9GO2dFQUNQbkIsV0FBVTs7Ozs7OzBFQUVaLDhEQUFDUzswRUFBT1U7Ozs7Ozs7dURBVEhDOzs7Ozs7Ozs7Ozs7bUNBaENQWjs7Ozs7MENBaURkLDhEQUFDYztnQ0FDQ1QsTUFBSztnQ0FDTGIsV0FBVTswQ0FDWDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBUWI7QUFFQSxpRUFBZWQsUUFBUUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2R5bmFtaWMtZm9ybS8uL2FwcC9bZm9ybVVSTF0vcGFnZS50c3g/ZDE5YSJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IEFQSV9ST1VURSwgRVJST1JfTUVTU0FHRSB9IGZyb20gXCIuLi9jb25zdGFudFwiO1xuaW1wb3J0IHsgRm9ybURhdGEsIEZvcm1GaWVsZCwgRm9ybVBhZ2VQcm9wcyB9IGZyb20gXCIuLi9pbnRlcmZhY2VcIjtcblxuY29uc3QgRm9ybVBhZ2UgPSAocHJvcHM6IEZvcm1QYWdlUHJvcHMpID0+IHtcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZTxGb3JtRGF0YSB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5nZXQoXG4gICAgICAgICAgYCR7QVBJX1JPVVRFLkdFVF9GT1JNX0JZX1VSTH0vJHtwcm9wcy5wYXJhbXMuZm9ybVVSTH1gXG4gICAgICAgICk7XG4gICAgICAgIGlmIChyZXNwb25zZSAmJiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgICAgc2V0Rm9ybURhdGEocmVzcG9uc2U/LmRhdGEpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKEVSUk9SX01FU1NBR0UuR0VUX0ZPUk1fQllfVVJMLCBlcnJvcik7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGlmIChwcm9wcy5wYXJhbXMuZm9ybVVSTCkge1xuICAgICAgZmV0Y2hEYXRhKCk7XG4gICAgfVxuICB9LCBbcHJvcHMucGFyYW1zLmZvcm1VUkxdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmF5LTEwMCBwLTAgc206cC0xMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzQ1cmVtXSBweC02IHB5LTEyIGJnLXdoaXRlIGJvcmRlci0wIHNoYWRvdy1sZyBzbTpyb3VuZGVkLTN4bFwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNFwiPntmb3JtRGF0YT8uZm9ybU5hbWV9PC9oMT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTEyXCI+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cIm1heC13LTJ4bCBteC1hdXRvXCI+XG4gICAgICAgICAgICB7Zm9ybURhdGE/LnF1ZXN0aW9ucyAmJlxuICAgICAgICAgICAgICBmb3JtRGF0YS5xdWVzdGlvbnMubWFwKChmaWVsZDogRm9ybUZpZWxkLCBpbmRleDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiICB0ZXh0LWJsYWNrIGZvbnQtc2VtaWJvbGQgXCI+XG4gICAgICAgICAgICAgICAgICAgIHtmaWVsZC50aXRsZX1cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICB7ZmllbGQuYW5zd2VyVHlwZSA9PT0gXCJUZXh0XCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJZb3VyIGFuc3dlclwiXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT17ZmllbGQudGl0bGUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKFwiIFwiLCBcIl9cIil9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHQtMyBwYi0yIGJsb2NrIHctZnVsbCBweC0wIG10LTAgYmctdHJhbnNwYXJlbnQgYm9yZGVyLTAgYm9yZGVyLWItMiBhcHBlYXJhbmNlLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMCBmb2N1czpib3JkZXItYmxhY2sgYm9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7ZmllbGQuYW5zd2VyVHlwZSA9PT0gXCJNdWx0aWNob2ljZSBDaGVja2JveFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZmllbGQuY2hvaWNlcy5tYXAoKGNob2ljZTogYW55LCBjaG9pY2VJbmRleDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y2hvaWNlSW5kZXh9IGNsYXNzTmFtZT1cInB0LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtmaWVsZC50aXRsZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoXCIgXCIsIFwiX1wiKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2hvaWNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTUgdGV4dC1ibGFjayBib3JkZXItMiBib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLWdyYXktMzAwIGZvY3VzOnJpbmctYmxhY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e2Nob2ljZX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtmaWVsZC5hbnN3ZXJUeXBlID09PSBcIlNpbmdsZSBTZWxlY3QgcmFkaW9cIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAge2ZpZWxkLmNob2ljZXMubWFwKChjaG9pY2U6IGFueSwgY2hvaWNlSW5kZXg6IG51bWJlcikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y2hvaWNlSW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgcHQtMyAgc3BhY2UteC00XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2ZpZWxkLnRpdGxlLnRvTG93ZXJDYXNlKCkucmVwbGFjZShcIiBcIiwgXCJfXCIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Nob2ljZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTIgdGV4dC1ibGFjayBib3JkZXItMiBib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLWdyYXktMzAwIGZvY3VzOnJpbmctYmxhY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPntjaG9pY2V9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQgaG92ZXI6YmctYmx1ZS02MDBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBTdWJtaXRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEZvcm1QYWdlO1xuIl0sIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXhpb3MiLCJBUElfUk9VVEUiLCJFUlJPUl9NRVNTQUdFIiwiRm9ybVBhZ2UiLCJwcm9wcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJmZXRjaERhdGEiLCJyZXNwb25zZSIsImdldCIsIkdFVF9GT1JNX0JZX1VSTCIsInBhcmFtcyIsImZvcm1VUkwiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZGl2IiwiY2xhc3NOYW1lIiwiaDEiLCJmb3JtTmFtZSIsImhyIiwiZm9ybSIsInF1ZXN0aW9ucyIsIm1hcCIsImZpZWxkIiwiaW5kZXgiLCJsYWJlbCIsInRpdGxlIiwiYW5zd2VyVHlwZSIsImlucHV0IiwidHlwZSIsInBsYWNlaG9sZGVyIiwibmFtZSIsInRvTG93ZXJDYXNlIiwicmVwbGFjZSIsImNob2ljZXMiLCJjaG9pY2UiLCJjaG9pY2VJbmRleCIsInZhbHVlIiwiYnV0dG9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./app/[formURL]/page.tsx\n");

/***/ }),

/***/ "(ssr)/./app/constant.ts":
/*!*************************!*\
  !*** ./app/constant.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   API_ROUTE: () => (/* binding */ API_ROUTE),\n/* harmony export */   ERROR_MESSAGE: () => (/* binding */ ERROR_MESSAGE),\n/* harmony export */   FORMS_NOT_FOUND: () => (/* binding */ FORMS_NOT_FOUND),\n/* harmony export */   ROUTE: () => (/* binding */ ROUTE)\n/* harmony export */ });\nconst ERROR_MESSAGE = {\n    SOMETHING_WENT_WRONG: \"Something went wrong\",\n    FORM_LIST: \"Error fetching form list:\",\n    GET_FORM_BY_URL: \"Error fetching form data:\"\n};\nconst ROUTE = {\n    FORM_LIST: \"/form-list\",\n    HOME: \"/\"\n};\nconst FORMS_NOT_FOUND = \"Forms not found.\";\nconst API_ROUTE = {\n    FORM_LIST: \"http://localhost:3001/form/list\",\n    GET_FORM_BY_URL: \"http://localhost:3001/form\",\n    CREATE_FORM: \"http://localhost:3001/form/create\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9hcHAvY29uc3RhbnQudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFPLE1BQU1BLGdCQUFnQjtJQUMzQkMsc0JBQXNCO0lBQ3RCQyxXQUFXO0lBQ1hDLGlCQUFpQjtBQUNuQixFQUFFO0FBRUssTUFBTUMsUUFBUTtJQUNuQkYsV0FBVztJQUNYRyxNQUFNO0FBQ1IsRUFBRTtBQUVLLE1BQU1DLGtCQUFrQixtQkFBbUI7QUFFM0MsTUFBTUMsWUFBWTtJQUN2QkwsV0FBVztJQUNYQyxpQkFBaUI7SUFDakJLLGFBQWE7QUFDZixFQUFFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZHluYW1pYy1mb3JtLy4vYXBwL2NvbnN0YW50LnRzP2FmNDQiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IEVSUk9SX01FU1NBR0UgPSB7XG4gIFNPTUVUSElOR19XRU5UX1dST05HOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXG4gIEZPUk1fTElTVDogXCJFcnJvciBmZXRjaGluZyBmb3JtIGxpc3Q6XCIsXG4gIEdFVF9GT1JNX0JZX1VSTDogXCJFcnJvciBmZXRjaGluZyBmb3JtIGRhdGE6XCIsXG59O1xuXG5leHBvcnQgY29uc3QgUk9VVEUgPSB7XG4gIEZPUk1fTElTVDogXCIvZm9ybS1saXN0XCIsXG4gIEhPTUU6IFwiL1wiLFxufTtcblxuZXhwb3J0IGNvbnN0IEZPUk1TX05PVF9GT1VORCA9IFwiRm9ybXMgbm90IGZvdW5kLlwiO1xuXG5leHBvcnQgY29uc3QgQVBJX1JPVVRFID0ge1xuICBGT1JNX0xJU1Q6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAxL2Zvcm0vbGlzdFwiLFxuICBHRVRfRk9STV9CWV9VUkw6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAxL2Zvcm1cIixcbiAgQ1JFQVRFX0ZPUk06IFwiaHR0cDovL2xvY2FsaG9zdDozMDAxL2Zvcm0vY3JlYXRlXCIsXG59O1xuIl0sIm5hbWVzIjpbIkVSUk9SX01FU1NBR0UiLCJTT01FVEhJTkdfV0VOVF9XUk9ORyIsIkZPUk1fTElTVCIsIkdFVF9GT1JNX0JZX1VSTCIsIlJPVVRFIiwiSE9NRSIsIkZPUk1TX05PVF9GT1VORCIsIkFQSV9ST1VURSIsIkNSRUFURV9GT1JNIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./app/constant.ts\n");

/***/ }),

/***/ "(rsc)/./app/globals.css":
/*!*************************!*\
  !*** ./app/globals.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"8a5134ec035a\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvZ2xvYmFscy5jc3MiLCJtYXBwaW5ncyI6Ijs7OztBQUFBLGlFQUFlLGNBQWM7QUFDN0IsSUFBSSxLQUFVLEVBQUUsRUFBdUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9keW5hbWljLWZvcm0vLi9hcHAvZ2xvYmFscy5jc3M/MzcyZiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBcIjhhNTEzNGVjMDM1YVwiXG5pZiAobW9kdWxlLmhvdCkgeyBtb2R1bGUuaG90LmFjY2VwdCgpIH1cbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/globals.css\n");

/***/ }),

/***/ "(rsc)/./app/[formURL]/page.tsx":
/*!********************************!*\
  !*** ./app/[formURL]/page.tsx ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/[formURL]/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ "(rsc)/./app/layout.tsx":
/*!************************!*\
  !*** ./app/layout.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RootLayout),\n/* harmony export */   metadata: () => (/* binding */ metadata)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/font/google/target.css?{\"path\":\"app/layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"} */ \"(rsc)/./node_modules/next/font/google/target.css?{\\\"path\\\":\\\"app/layout.tsx\\\",\\\"import\\\":\\\"Inter\\\",\\\"arguments\\\":[{\\\"subsets\\\":[\\\"latin\\\"]}],\\\"variableName\\\":\\\"inter\\\"}\");\n/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals.css */ \"(rsc)/./app/globals.css\");\n\n\n\nconst metadata = {\n    title: \"Form builder\",\n    description: \"Generated by create next app\"\n};\nfunction RootLayout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"html\", {\n        lang: \"en\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n            className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),\n            children: children\n        }, void 0, false, {\n            fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/layout.tsx\",\n            lineNumber: 19,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/webclues/Desktop/Live-Projects/Dynamic-form/dynamic-form/app/layout.tsx\",\n        lineNumber: 18,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvbGF5b3V0LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUlNQTtBQUZpQjtBQUloQixNQUFNQyxXQUFxQjtJQUNoQ0MsT0FBTztJQUNQQyxhQUFhO0FBQ2YsRUFBRTtBQUVhLFNBQVNDLFdBQVcsRUFDakNDLFFBQVEsRUFHVDtJQUNDLHFCQUNFLDhEQUFDQztRQUFLQyxNQUFLO2tCQUNULDRFQUFDQztZQUFLQyxXQUFXVCwySkFBZTtzQkFBR0s7Ozs7Ozs7Ozs7O0FBR3pDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZHluYW1pYy1mb3JtLy4vYXBwL2xheW91dC50c3g/OTk4OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE1ldGFkYXRhIH0gZnJvbSBcIm5leHRcIjtcbmltcG9ydCB7IEludGVyIH0gZnJvbSBcIm5leHQvZm9udC9nb29nbGVcIjtcbmltcG9ydCBcIi4vZ2xvYmFscy5jc3NcIjtcblxuY29uc3QgaW50ZXIgPSBJbnRlcih7IHN1YnNldHM6IFtcImxhdGluXCJdIH0pO1xuXG5leHBvcnQgY29uc3QgbWV0YWRhdGE6IE1ldGFkYXRhID0ge1xuICB0aXRsZTogXCJGb3JtIGJ1aWxkZXJcIixcbiAgZGVzY3JpcHRpb246IFwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm9vdExheW91dCh7XG4gIGNoaWxkcmVuLFxufToge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxodG1sIGxhbmc9XCJlblwiPlxuICAgICAgPGJvZHkgY2xhc3NOYW1lPXtpbnRlci5jbGFzc05hbWV9PntjaGlsZHJlbn08L2JvZHk+XG4gICAgPC9odG1sPlxuICApO1xufVxuIl0sIm5hbWVzIjpbImludGVyIiwibWV0YWRhdGEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiUm9vdExheW91dCIsImNoaWxkcmVuIiwiaHRtbCIsImxhbmciLCJib2R5IiwiY2xhc3NOYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/layout.tsx\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mime-db","vendor-chunks/axios","vendor-chunks/follow-redirects","vendor-chunks/debug","vendor-chunks/form-data","vendor-chunks/asynckit","vendor-chunks/combined-stream","vendor-chunks/mime-types","vendor-chunks/proxy-from-env","vendor-chunks/ms","vendor-chunks/delayed-stream","vendor-chunks/@swc"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2F%5BformURL%5D%2Fpage&page=%2F%5BformURL%5D%2Fpage&appPaths=%2F%5BformURL%5D%2Fpage&pagePath=private-next-app-dir%2F%5BformURL%5D%2Fpage.tsx&appDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fwebclues%2FDesktop%2FLive-Projects%2FDynamic-form%2Fdynamic-form&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();