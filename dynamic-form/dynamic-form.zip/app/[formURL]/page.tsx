"use client";
import { useEffect, useState } from "react";
import axios from "axios";
import { API_ROUTE, ERROR_MESSAGE } from "../constant";
import { FormData, FormField, FormPageProps } from "../interface";

const FormPage = (props: FormPageProps) => {
  const [formData, setFormData] = useState<FormData | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${API_ROUTE.GET_FORM_BY_URL}/${props.params.formURL}`
        );
        if (response && response.data) {
          setFormData(response?.data);
        }
      } catch (error) {
        console.error(ERROR_MESSAGE.GET_FORM_BY_URL, error);
      }
    };

    if (props.params.formURL) {
      fetchData();
    }
  }, [props.params.formURL]);

  return (
    <>
      <div className="min-h-screen bg-gray-100 p-0 sm:p-12">
        <div className="mx-auto max-w-[45rem] px-6 py-12 bg-white border-0 shadow-lg sm:rounded-3xl">
          <h1 className="text-2xl font-bold mb-4">{formData?.formName}</h1>
          <div className="pb-12">
            <hr />
          </div>

          <form className="max-w-2xl mx-auto">
            {formData?.questions &&
              formData.questions.map((field: FormField, index: number) => (
                <div key={index} className="mb-6">
                  <label className="  text-black font-semibold ">
                    {field.title}
                  </label>
                  {field.answerType === "Text" && (
                    <input
                      type="text"
                      placeholder="Your answer"
                      name={field.title.toLowerCase().replace(" ", "_")}
                      className="pt-3 pb-2 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-300"
                    />
                  )}
                  {field.answerType === "Multichoice Checkbox" && (
                    <div>
                      {field.choices.map((choice: any, choiceIndex: number) => (
                        <div key={choiceIndex} className="pt-3">
                          <input
                            type="checkbox"
                            name={field.title.toLowerCase().replace(" ", "_")}
                            value={choice}
                            className="mr-5 text-black border-2 border-gray-300 focus:border-gray-300 focus:ring-black"
                          />
                          <label>{choice}</label>
                        </div>
                      ))}
                    </div>
                  )}
                  {field.answerType === "Single Select radio" && (
                    <div>
                      {field.choices.map((choice: any, choiceIndex: number) => (
                        <>
                          <div
                            key={choiceIndex}
                            className="block pt-3  space-x-4"
                          >
                            <input
                              type="radio"
                              name={field.title.toLowerCase().replace(" ", "_")}
                              value={choice}
                              className="mr-2 text-black border-2 border-gray-300 focus:border-gray-300 focus:ring-black"
                            />
                            <label>{choice}</label>
                          </div>
                        </>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            <button
              type="submit"
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Submit
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default FormPage;
