import React from "react";
import DynamicForm from "./components/DynamicForm";

const Home = () => {
  return (
    <div>
      <DynamicForm />
    </div>
  );
};

export default Home;
